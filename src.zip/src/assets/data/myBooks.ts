import {BookInformation} from '../../app/bookInfo';

export const MYBOOKS : BookInformation[] = 
[
    { bname:'King Of Malorn' , aname: 'Annie Douglass Lima' , genre:'Art' , year:2000 , picture:'assets/images/KingOfMalornfinal.jpg'},
    { bname: 'The Midnight front' , aname: 'David Mack', genre:'Art' , year:1995 , picture:'assets/images/Midnight.jpg'},
    { bname: 'Folk and farytale' , aname : 'Martin Hallett', genre:'Stories', year:1991 , picture:'assets/images/Folk.jpg'},
    { bname: 'Pride and Prejudice', aname: 'Jane Austen', genre:'romantic' ,year:2000 ,picture:'assets/images/pride.jpg'}

]