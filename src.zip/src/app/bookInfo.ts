export class BookInformation{

 bname: string;
 aname : string;
 genre: string;
 year : number;
 picture: string;

}