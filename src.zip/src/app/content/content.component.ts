import { Component, OnInit } from '@angular/core';
import {Harmanh} from '../harmanh';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
    StudentInfo : Harmanh = { 
    snumber: 991471507,
    sname : "Harman Harman",
    slogin : "harmanh",
    scampus : "Davis",
    stitle : "Assignment3"   } 

  constructor() { }

  ngOnInit() {
  }

}
