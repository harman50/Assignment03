import { Component, OnInit } from '@angular/core';
import { MYBOOKS } from 'src/assets/data/myBooks';
import { BookInformation } from '../bookInfo';

@Component({
  selector: 'app-harmanh',
  templateUrl: './harmanh.component.html',
  styleUrls: ['./harmanh.component.css']
})

export class HarmanhComponent implements OnInit {
  
  myBooks  = MYBOOKS;

  bookPicked : BookInformation;
  bname: string;
  aname : string;
  genre: string;
  year : number;
  picture: string;

  constructor() { }

  ngOnInit() {
    this.buttonClick(0)
  }

  buttonClick(index){
    this.bookPicked={
    
    bname:this.myBooks[index].bname,
    aname:this.myBooks[index].aname,
    genre:this.myBooks[index].genre,
    year:this.myBooks[index].year,
    picture:this.myBooks[index].picture,
   
      

  }
 }
}

