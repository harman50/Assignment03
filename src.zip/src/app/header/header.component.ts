import { Component, OnInit } from '@angular/core';
import {Harmanh} from '../harmanh';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {
   
    StudentInfo : Harmanh = { 
    snumber: 991471507,
    sname : "Harman Harman",
    slogin : "harmanh",
    scampus : "Davis",
    stitle : "Assignment3"   }      

  constructor() { }

  ngOnInit() {
  }

}
