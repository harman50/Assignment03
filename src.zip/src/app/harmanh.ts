export class Harmanh{
    snumber: number;
    sname : string;
    slogin : string;
    scampus :string;
    stitle : string;
}