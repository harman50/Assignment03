import { Component, OnInit } from '@angular/core';
import {Harmanh} from '../harmanh';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
    StudentInfo : Harmanh = { 
    snumber: 991471507,
    sname : "Harman Harman",
    slogin : "harmanh",
    scampus : "Davis",
    stitle : "Assignment3"   } 

  constructor() { }

  ngOnInit() {
  }

}
